import { HomeIcon, ShieldIcon } from "lucide-react";
import Index from "./pages/Index.jsx";
import AdminPanel from "./components/AdminPanel.jsx";

export const navItems = [
  {
    title: "Home",
    to: "/",
    icon: <HomeIcon className="h-4 w-4" />,
    page: <Index />,
  },
  {
    title: "Admin",
    to: "/admin",
    icon: <ShieldIcon className="h-4 w-4" />,
    page: <AdminPanel />,
  },
];