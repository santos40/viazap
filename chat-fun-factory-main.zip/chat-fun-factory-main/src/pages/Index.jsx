import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Share2 } from "lucide-react";
import { Link } from "react-router-dom";
import FeaturedEntry from "@/components/FeaturedEntry";

const Index = () => {
  const [featuredEntries, setFeaturedEntries] = useState([
    { 
      id: 1, 
      name: "João Silva", 
      type: "Profissional", 
      specialty: "Eletricista", 
      whatsapp: "11987654321", 
      likes: 10, 
      dislikes: 2,
      description: "Eletricista experiente com mais de 10 anos no mercado.",
      logo: "/path/to/joao-logo.png",
      registrationDate: "2024-03-01",
      paid: true,
      selected: false
    },
    { 
      id: 2, 
      name: "Maria Santos", 
      type: "Profissional", 
      specialty: "Designer Gráfico", 
      whatsapp: "21976543210", 
      likes: 15, 
      dislikes: 1,
      description: "Designer gráfica especializada em identidade visual para pequenas empresas.",
      logo: "/path/to/maria-logo.png" // Placeholder path, replace with actual path
    },
    { 
      id: 3, 
      name: "Construções XYZ", 
      type: "Empresa", 
      specialty: "Construção Civil", 
      whatsapp: "31965432109", 
      likes: 8, 
      dislikes: 3,
      description: "Especialistas em obras residenciais e comerciais.",
      logo: "/path/to/construcoes-logo.png" // Placeholder path, replace with actual path
    },
    { 
      id: 4, 
      name: "Tech Solutions", 
      type: "Empresa", 
      specialty: "Desenvolvimento de Software", 
      whatsapp: "41954321098", 
      likes: 20, 
      dislikes: 0,
      description: "Soluções tecnológicas para o seu negócio.",
      logo: "/path/to/techsolutions-logo.png" // Placeholder path, replace with actual path
    },
  ]);

  const handleFeedback = (id, type) => {
    setFeaturedEntries(entries =>
      entries.map(entry =>
        entry.id === id
          ? { ...entry, [type]: entry[type] + 1 }
          : entry
      )
    );
  };

  const handleWhatsApp = (number, name) => {
    const message = encodeURIComponent(`Olá ${name}, te achei no site solicitarorcamento.com`);
    window.open(`https://wa.me/${number}?text=${message}`, '_blank');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'ZAP1 Profissionais',
        text: 'Encontre os melhores profissionais e empresas!',
        url: window.location.href,
      })
        .then(() => console.log('Conteúdo compartilhado com sucesso'))
        .catch((error) => console.log('Erro ao compartilhar:', error));
    } else {
      console.log('Web Share API não suportada');
    }
  };

  const handleSelect = (id) => {
    setFeaturedEntries(entries =>
      entries.map(entry =>
        entry.id === id
          ? { ...entry, selected: !entry.selected }
          : entry
      )
    );
  };

  return (
    <div className="space-y-8">
      <section className="text-center">
        <h2 className="text-3xl font-bold mb-4">Encontre os Melhores Profissionais</h2>
        <p className="text-lg text-gray-600 mb-6">Conecte-se com especialistas qualificados</p>
        <div className="flex justify-center space-x-4">
          <Link to="/register">
            <Button size="lg" variant="secondary">Cadastre-se</Button>
          </Link>
          <Button size="lg" variant="outline" onClick={handleShare}>
            <Share2 className="mr-2 h-4 w-4" /> Compartilhar
          </Button>
        </div>
      </section>
      
      <Tabs defaultValue="featured" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="featured">Destaques</TabsTrigger>
          <TabsTrigger value="categories">Categorias</TabsTrigger>
        </TabsList>
      
        <TabsContent value="featured">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredEntries.map((entry) => (
              <FeaturedEntry
                key={entry.id}
                entry={entry}
                onFeedback={handleFeedback}
                onSelect={handleSelect}
                onWhatsApp={handleWhatsApp}
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="categories">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {['Empresas', 'Profissionais', 'Pedir Orçamento'].map((item) => (
              <Card key={item}>
                <CardHeader>
                  <CardTitle>{item}</CardTitle>
                  <CardDescription>{item === 'Pedir Orçamento' ? 'Solicite um orçamento personalizado' : `Cadastre-se como ${item.toLowerCase()}`}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Link to={item === 'Pedir Orçamento' ? '/request-quote' : '/register'}>
                    <Button variant="outline" className="w-full">
                      {item === 'Pedir Orçamento' ? 'Solicitar' : 'Cadastrar'}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Index;
