import React from 'react';
import RegisterForm from "@/components/RegisterForm";

const RegisterPage = () => {
  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Cadastro</h2>
      <RegisterForm />
    </div>
  );
};

export default RegisterPage;