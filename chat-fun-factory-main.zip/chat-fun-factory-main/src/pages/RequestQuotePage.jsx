import React from 'react';
import RequestQuoteForm from "@/components/RequestQuoteForm";

const RequestQuotePage = () => {
  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">Pedir Orçamento</h2>
      <RequestQuoteForm />
    </div>
  );
};

export default RequestQuotePage;