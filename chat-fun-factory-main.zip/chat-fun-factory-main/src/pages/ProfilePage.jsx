import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star, MessageCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const ProfilePage = () => {
  const { id } = useParams();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  // Placeholder profile data (replace with actual data fetching logic)
  const profile = {
    id: id,
    name: "John Doe",
    type: "Profissional",
    specialty: "Eletricista",
    whatsapp: "11987654321",
    description: "Eletricista experiente com mais de 10 anos no mercado.",
    logo: "/path/to/john-logo.png"
  };

  const handleRating = (value) => {
    setRating(value);
  };

  const handleComment = (e) => {
    setComment(e.target.value);
  };

  const handleSubmitFeedback = () => {
    console.log('Feedback submitted:', { rating, comment });
    // Implement the logic to send feedback to the backend
    setRating(0);
    setComment('');
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent(`Olá ${profile.name}, te achei no site solicitarorcamento.com`);
    window.open(`https://wa.me/${profile.whatsapp}?text=${message}`, '_blank');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-4">
            <img src={profile.logo} alt={`${profile.name} logo`} className="w-16 h-16 object-cover rounded-full" />
            <div>
              <CardTitle>{profile.name}</CardTitle>
              <CardDescription>{profile.type}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p><strong>Especialidade:</strong> {profile.specialty}</p>
          <p><strong>Descrição:</strong> {profile.description}</p>
          <Button 
            onClick={handleWhatsApp}
            className="mt-4 bg-green-500 hover:bg-green-600 text-white"
          >
            Contatar via WhatsApp
          </Button>
        </CardContent>
      </Card>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Avaliação e Comentários</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <h4 className="mb-2 font-semibold">Sua Avaliação</h4>
            <div className="flex mb-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`cursor-pointer ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                  onClick={() => handleRating(star)}
                />
              ))}
            </div>
          </div>
          <div className="mb-4">
            <h4 className="mb-2 font-semibold">Seu Comentário</h4>
            <Textarea
              placeholder="Deixe seu comentário..."
              value={comment}
              onChange={handleComment}
            />
          </div>
          <Button onClick={handleSubmitFeedback}>
            Enviar Feedback
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;