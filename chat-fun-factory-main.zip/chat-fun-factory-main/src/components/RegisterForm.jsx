import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const formSchema = z.object({
  name: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  password: z.string().min(6, { message: "A senha deve ter pelo menos 6 caracteres" }),
  type: z.enum(["professional", "company"]),
  description: z.string().min(10, { message: "A descrição deve ter pelo menos 10 caracteres" }),
  facebook: z.string().url({ message: "URL do Facebook inválida" }).optional().or(z.literal('')),
  instagram: z.string().url({ message: "URL do Instagram inválida" }).optional().or(z.literal('')),
  linkedin: z.string().url({ message: "URL do LinkedIn inválida" }).optional().or(z.literal('')),
  logo: z.instanceof(File).optional(),
  photos: z.array(z.instanceof(File)).max(4).optional(),
});

const RegisterForm = () => {
  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "", email: "", password: "", type: "professional", description: "",
      facebook: "", instagram: "", linkedin: "", logo: undefined, photos: [],
    },
  });

  const onSubmit = (values) => {
    const registrationDate = new Date().toISOString();
    console.log({ ...values, registrationDate });
    // Implementar lógica de registro aqui
  };

  const renderFormField = (name, label, type = "text", options = null) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            {type === "select" ? (
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder={`Selecione o ${label.toLowerCase()}`} />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {options.map(option => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : type === "textarea" ? (
              <Textarea {...field} placeholder={`Digite ${label.toLowerCase()}...`} />
            ) : type === "file" ? (
              <Input type="file" accept="image/*" onChange={(e) => field.onChange(e.target.files[0])} />
            ) : (
              <Input {...field} type={type} placeholder={`Digite ${label.toLowerCase()}...`} />
            )}
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        {renderFormField("name", "Nome")}
        {renderFormField("email", "Email", "email")}
        {renderFormField("password", "Senha", "password")}
        {renderFormField("type", "Tipo de Conta", "select", [
          { value: "professional", label: "Profissional" },
          { value: "company", label: "Empresa" }
        ])}
        {renderFormField("description", "Descrição", "textarea")}
        {renderFormField("logo", "Logotipo", "file")}
        {renderFormField("photos", "Fotos (máximo 4)", "file")}
        {renderFormField("facebook", "Facebook (opcional)")}
        {renderFormField("instagram", "Instagram (opcional)")}
        {renderFormField("linkedin", "LinkedIn (opcional)")}
        <Button type="submit" className="w-full" variant="orange">Cadastrar</Button>
      </form>
    </Form>
  );
};

export default RegisterForm;
