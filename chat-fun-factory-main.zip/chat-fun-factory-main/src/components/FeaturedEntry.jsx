import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ThumbsUp, ThumbsDown } from "lucide-react";
import { Link } from "react-router-dom";
import { Checkbox } from "@/components/ui/checkbox";

const FeaturedEntry = ({ entry, onFeedback, onSelect, onWhatsApp }) => {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img src={entry.logo} alt={`${entry.name} logo`} className="w-16 h-16 object-cover rounded-full" />
            <div>
              <CardTitle>{entry.name}</CardTitle>
              <CardDescription>{entry.type}</CardDescription>
            </div>
          </div>
          <Checkbox
            checked={entry.selected}
            onCheckedChange={() => onSelect(entry.id)}
          />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600 mb-2">{entry.specialty}</p>
        <p className="text-sm text-gray-600 mb-2">{entry.description}</p>
        <p className="text-sm text-gray-600 mb-2">Cadastrado em: {formatDate(entry.registrationDate)}</p>
        <p className="text-sm font-semibold mb-2">Status: {entry.paid ? 'Pago' : 'Não Pago'}</p>
        <Button 
          variant="secondary"
          className="w-full mb-2" 
          onClick={() => onWhatsApp(entry.whatsapp, entry.name)}
        >
          WhatsApp
        </Button>
        <div className="flex justify-between items-center">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onFeedback(entry.id, 'likes')}
          >
            <ThumbsUp className="mr-1" /> {entry.likes}
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onFeedback(entry.id, 'dislikes')}
          >
            <ThumbsDown className="mr-1" /> {entry.dislikes}
          </Button>
        </div>
        <Link to={`/profile/${entry.id}`} className="block mt-2">
          <Button variant="link" className="w-full">Ver Perfil</Button>
        </Link>
      </CardContent>
    </Card>
  );
};

export default FeaturedEntry;
