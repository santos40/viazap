import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Drawer, DrawerClose, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";
import { Menu } from 'lucide-react';
import { navItems } from "@/nav-items";

const MobileMenu = () => {
  return (
    <Drawer>
      <DrawerTrigger asChild>
        <Button variant="outline" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
        </Button>
      </DrawerTrigger>
      <DrawerContent className="bg-green-500 text-white">
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-4">Menu</h2>
          <nav className="space-y-2">
            {navItems.map((item) => (
              <DrawerClose asChild key={item.to}>
                <Link to={item.to} className="flex items-center p-2 hover:bg-green-600 rounded">
                  {item.icon}
                  <span className="ml-2">{item.title}</span>
                </Link>
              </DrawerClose>
            ))}
            <DrawerClose asChild>
              <Link to="/login" className="flex items-center p-2 hover:bg-green-600 rounded">
                <span className="ml-2">Login</span>
              </Link>
            </DrawerClose>
            <DrawerClose asChild>
              <Link to="/register" className="flex items-center p-2 hover:bg-green-600 rounded">
                <span className="ml-2">Cadastro</span>
              </Link>
            </DrawerClose>
            <DrawerClose asChild>
              <Link to="/request-quote" className="flex items-center p-2 hover:bg-green-600 rounded">
                <span className="ml-2">Pedir Orçamento</span>
              </Link>
            </DrawerClose>
          </nav>
        </div>
      </DrawerContent>
    </Drawer>
  );
};

export default MobileMenu;