import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { categories as initialCategories } from "@/data/categories";

const AdminPanel = () => {
  const [users, setUsers] = useState([
    { id: 1, name: 'João Silva', type: 'Profissional', category: 'Eletricista', status: 'Ativo' },
    { id: 2, name: 'Empresa XYZ', type: 'Empresa', category: 'Construção', status: 'Pendente' },
  ]);
  const [plans, setPlans] = useState([
    { id: 1, name: 'Plano Empresa', price: '99.99' },
    { id: 2, name: 'Plano Profissional', price: '49.99' },
    { id: 3, name: 'Pedido de Orçamento', price: '9.99' },
  ]);
  const [categories, setCategories] = useState(initialCategories);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [editingType, setEditingType] = useState('');

  const handleEdit = (item, type) => {
    setEditingItem(item);
    setEditingType(type);
    setShowEditDialog(true);
  };

  const handleDelete = (id, type) => {
    if (type === 'user') {
      setUsers(users.filter(user => user.id !== id));
    } else if (type === 'plan') {
      setPlans(plans.filter(plan => plan.id !== id));
    } else if (type === 'category') {
      setCategories(categories.filter(category => category !== id));
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (editingType === 'user') {
      setUsers(users.map(user => user.id === editingItem.id ? {
        ...editingItem,
        name: e.target.name.value,
        type: e.target.type.value,
        category: e.target.category.value,
        status: e.target.status.value
      } : user));
    } else if (editingType === 'plan') {
      setPlans(plans.map(plan => plan.id === editingItem.id ? {
        ...editingItem,
        name: e.target.name.value,
        price: e.target.price.value
      } : plan));
    } else if (editingType === 'category') {
      const newCategories = [...categories];
      const index = newCategories.indexOf(editingItem);
      if (index !== -1) {
        newCategories[index] = e.target.name.value;
        setCategories(newCategories);
      }
    }
    setShowEditDialog(false);
  };

  const handleAddCategory = () => {
    const newCategory = prompt("Digite o nome da nova categoria:");
    if (newCategory && !categories.includes(newCategory)) {
      setCategories([...categories, newCategory]);
    }
  };

  const renderTable = (items, type) => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            {type === 'user' && <TableHead>Tipo</TableHead>}
            {type === 'user' && <TableHead>Categoria</TableHead>}
            {type === 'user' && <TableHead>Status</TableHead>}
            {type === 'plan' && <TableHead>Preço</TableHead>}
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={type === 'category' ? item : item.id}>
              <TableCell>{type === 'category' ? item : item.name}</TableCell>
              {type === 'user' && <TableCell>{item.type}</TableCell>}
              {type === 'user' && <TableCell>{item.category}</TableCell>}
              {type === 'user' && <TableCell>{item.status}</TableCell>}
              {type === 'plan' && <TableCell>R$ {item.price}</TableCell>}
              <TableCell>
                <Button variant="outline" className="mr-2 mb-2" onClick={() => handleEdit(item, type)}>Editar</Button>
                <Button variant="destructive" onClick={() => handleDelete(type === 'category' ? item : item.id, type)}>Deletar</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Painel de Administração</h2>
      <Tabs defaultValue="users">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">Usuários</TabsTrigger>
          <TabsTrigger value="plans">Planos</TabsTrigger>
          <TabsTrigger value="categories">Categorias</TabsTrigger>
        </TabsList>
        <TabsContent value="users">
          {renderTable(users, 'user')}
        </TabsContent>
        <TabsContent value="plans">
          {renderTable(plans, 'plan')}
        </TabsContent>
        <TabsContent value="categories">
          {renderTable(categories, 'category')}
          <Button onClick={handleAddCategory} className="mt-4" variant="secondary">Adicionar Categoria</Button>
        </TabsContent>
      </Tabs>

      {showEditDialog && (
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar {editingType === 'user' ? 'Usuário' : editingType === 'plan' ? 'Plano' : 'Categoria'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <Input
                  name="name"
                  defaultValue={editingType === 'category' ? editingItem : editingItem.name}
                  placeholder="Nome"
                />
              </div>
              {editingType === 'user' && (
                <>
                  <div>
                    <Select name="type" defaultValue={editingItem.type}>
                      <SelectTrigger>
                        <SelectValue placeholder="Tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Profissional">Profissional</SelectItem>
                        <SelectItem value="Empresa">Empresa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Select name="category" defaultValue={editingItem.category}>
                      <SelectTrigger>
                        <SelectValue placeholder="Categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Select name="status" defaultValue={editingItem.status}>
                      <SelectTrigger>
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Ativo">Ativo</SelectItem>
                        <SelectItem value="Pendente">Pendente</SelectItem>
                        <SelectItem value="Inativo">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
              {editingType === 'plan' && (
                <div>
                  <Input
                    name="price"
                    defaultValue={editingItem.price}
                    placeholder="Preço"
                  />
                </div>
              )}
              <DialogFooter>
                <Button type="submit" variant="secondary">Salvar</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default AdminPanel;
