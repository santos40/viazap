export const categories = [
  "Encanador",
  "Pintor",
  "Eletricista"
];