import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { navItems } from "./nav-items";
import PaymentPage from "./pages/PaymentPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import RequestQuotePage from "./pages/RequestQuotePage";
import ProfilePage from "./pages/ProfilePage";
import MobileMenu from "./components/MobileMenu";

const queryClient = new QueryClient();

const Layout = ({ children }) => (
  <div className="min-h-screen flex flex-col">
    <header className="bg-green-500 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Solicitar Orçamento</h1>
        <nav className="hidden md:flex space-x-4">
          {navItems.map((item) => (
            <Link key={item.to} to={item.to} className="hover:text-green-200">
              {item.title}
            </Link>
          ))}
          <Link to="/login" className="hover:text-green-200">Login</Link>
          <Link to="/register" className="hover:text-green-200">Cadastro</Link>
          <Link to="/request-quote" className="hover:text-green-200">Pedir Orçamento</Link>
        </nav>
        <MobileMenu />
      </div>
    </header>
    <main className="flex-grow container mx-auto px-4 py-8">
      {children}
    </main>
    <footer className="bg-gray-100">
      <div className="container mx-auto px-4 py-6 text-center text-gray-600">
        &copy; 2024 Solicitar Orçamento. Todos os direitos reservados.
      </div>
    </footer>
  </div>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <BrowserRouter>
        <Routes>
          {navItems.map(({ to, page }) => (
            <Route key={to} path={to} element={<Layout>{page}</Layout>} />
          ))}
          <Route path="/payment" element={<Layout><PaymentPage /></Layout>} />
          <Route path="/login" element={<Layout><LoginPage /></Layout>} />
          <Route path="/register" element={<Layout><RegisterPage /></Layout>} />
          <Route path="/request-quote" element={<Layout><RequestQuotePage /></Layout>} />
          <Route path="/profile/:id" element={<Layout><ProfilePage /></Layout>} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;